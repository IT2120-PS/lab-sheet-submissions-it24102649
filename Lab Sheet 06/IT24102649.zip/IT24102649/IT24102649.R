setwd("C:\\Users\\Liyanage D C J\\Desktop\\IT24102649")
getwd()
#Question 01
#Part1 
#Binomial Distribution
#Here, random variable X has binomial distribution with n=50 and p=0.85

#Part2
dbinom(47,50,0.85)


#Question 02
#Part1
#Number of customer calls recieved in an hour

#Part2
#Poisson distribution
#Here, random variable X has poisson distribution with lambda=12

#Part3
dpois(12,15)